#!/usr/bin/env python3
"""
Generate shirt geometry + textures from flat-lay product photos.

    ./scripts/generate-shirt.py --front public/shirt/front.webp
    ./scripts/generate-shirt.py --front f.webp --back b.webp

Writes:
    public/shirt/<name>-front.webp      baked front print
    public/shirt/<name>-back.webp       baked back print (only with --back)
    src/components/shirtAsset.generated.ts   outline + paths for ShirtScene

Why it works without a 3D model: the scene extrudes a single 2D outline, so
a flat-lay shot already contains everything needed - the silhouette (from the
alpha matte) and the surface (the photo itself). The bundled/crumpled pose is
derived from the base vertices at runtime, so it is never authored.

Requires: pillow, numpy, opencv-python
"""

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def load_rgba(path: Path) -> np.ndarray:
    image = Image.open(path)
    if image.mode != "RGBA":
        image = image.convert("RGBA")
    return np.array(image)


def silhouette_mask(pixels: np.ndarray) -> np.ndarray:
    """Prefer a real alpha matte; fall back to thresholding a light backdrop."""
    alpha = pixels[..., 3]

    if (alpha > 0).sum() < alpha.size * 0.02:
        print("  no usable alpha matte - thresholding near-white background")
        diff = np.abs(pixels[..., :3].astype(np.int16) - 255).sum(axis=2)
        mask = (diff > 40).astype(np.uint8) * 255
    else:
        mask = (alpha > 128).astype(np.uint8) * 255

    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))


def largest_contour(mask: np.ndarray):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        sys.exit("error: found no garment in the image")
    return max(contours, key=cv2.contourArea).reshape(-1, 2).astype(np.float64)


def resample(points: np.ndarray, count: int) -> np.ndarray:
    """Uniform arc-length sampling, which keeps sleeve caps from being
    under-represented the way a curvature-based simplifier would."""
    closed = np.vstack([points, points[:1]])
    segment = np.linalg.norm(np.diff(closed, axis=0), axis=1)
    cumulative = np.concatenate([[0.0], np.cumsum(segment)])

    at = np.linspace(0, cumulative[-1], count, endpoint=False)

    return np.column_stack(
        [
            np.interp(at, cumulative, closed[:, 0]),
            np.interp(at, cumulative, closed[:, 1]),
        ]
    )


def fidelity(mask: np.ndarray, polygon: np.ndarray) -> float:
    filled = np.zeros_like(mask)
    cv2.fillPoly(filled, [polygon.astype(np.int32).reshape(-1, 1, 2)], 255)

    intersection = np.logical_and(filled > 0, mask > 0).sum()
    union = np.logical_or(filled > 0, mask > 0).sum()

    return intersection / max(1, union)


def bake(pixels: np.ndarray, bbox, average_rgb, tex_width: int) -> Image.Image:
    """Crop to the garment and flatten alpha over the garment's own colour.

    Leaving transparency in place would blend edge texels toward black, which
    shows up as a dark outline around the silhouette once it is lit.
    """
    x, y, w, h = bbox

    alpha = pixels[..., 3:4] / 255.0
    rgb = pixels[..., :3].astype(np.float32)

    composited = rgb * alpha + average_rgb[None, None, :] * (1.0 - alpha)
    crop = np.clip(composited, 0, 255).astype(np.uint8)[y : y + h, x : x + w]

    image = Image.fromarray(crop)
    height = int(round(tex_width * h / w))

    return image.resize((tex_width, height), Image.LANCZOS)


def average_colour(pixels: np.ndarray, mask: np.ndarray) -> np.ndarray:
    inside = mask > 0
    return pixels[..., :3][inside].mean(axis=0).round(1)


def web_url(path: Path) -> str:
    """Astro serves public/ at the site root, so the runtime URL drops it."""
    parts = path.as_posix().split("/")

    if "public" in parts:
        parts = parts[parts.index("public") + 1 :]

    return "/" + "/".join(parts)


def to_centimetres(points, bbox, width_cm: float):
    """Image space (y down) to shape space (y up), centred on the garment."""
    x, y, w, h = bbox
    height_cm = width_cm * h / w

    return [
        (
            round(((px - x) / w - 0.5) * width_cm, 1),
            round((0.5 - (py - y) / h) * height_cm, 1),
        )
        for px, py in points
    ], height_cm


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--front", required=True, type=Path)
    parser.add_argument("--back", type=Path)
    parser.add_argument("--name", default="shirt")
    parser.add_argument("--width-cm", type=float, default=136.0)
    parser.add_argument("--points", type=int, default=64)
    parser.add_argument("--tex-width", type=int, default=1024)
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--module", type=Path)
    args = parser.parse_args()

    # Anchor the generated files to the project root rather than the current
    # directory, so running this from scripts/ cannot scatter output into a
    # shadow tree that the app never loads.
    root = Path(__file__).resolve().parent.parent

    out_dir = args.out_dir or root / "public/shirt"
    module = args.module or root / "src/components/shirtAsset.generated.ts"

    if not module.is_absolute():
        module = root / module
    if not out_dir.is_absolute():
        out_dir = root / out_dir

    args.out_dir = out_dir
    args.module = module

    if not args.front.exists():
        sys.exit(f"error: no such file: {args.front}")
    if args.back and not args.back.exists():
        sys.exit(f"error: no such file: {args.back}")

    args.out_dir.mkdir(parents=True, exist_ok=True)

    print(f"project root: {root}")
    print(f"  textures -> {args.out_dir}")
    print(f"  module   -> {args.module}")

    print(f"front: {args.front}")
    front_pixels = load_rgba(args.front)
    front_mask = silhouette_mask(front_pixels)
    front_contour = largest_contour(front_mask)
    front_bbox = cv2.boundingRect(front_contour.astype(np.int32))
    fx, fy, fw, fh = front_bbox

    pixel_outline = resample(front_contour, args.points)
    score = fidelity(front_mask, pixel_outline)

    outline, height_cm = to_centimetres(
        pixel_outline, front_bbox, args.width_cm
    )

    print(f"  bbox {front_bbox}  aspect h/w {fh / fw:.3f}  outline IoU {score:.4f}")

    rim_rgb = average_colour(front_pixels, front_mask)
    rim_hex = "#%02x%02x%02x" % tuple(rim_rgb.astype(int))
    print(f"  garment colour {rim_hex}")

    front_path = args.out_dir / f"{args.name}-front.webp"
    bake(front_pixels, front_bbox, rim_rgb, args.tex_width).save(
        front_path, "WEBP", quality=92
    )
    print(f"  wrote {front_path}")

    back_ref = "null"
    if args.back:
        print(f"back: {args.back}")
        back_pixels = load_rgba(args.back)
        back_mask = silhouette_mask(back_pixels)
        back_contour = largest_contour(back_mask)
        back_bbox = cv2.boundingRect(back_contour.astype(np.int32))

        ratio = (back_bbox[3] / back_bbox[2]) / (fh / fw)
        if abs(ratio - 1.0) > 0.03:
            print(
                f"  warning: back aspect differs from front by "
                f"{abs(ratio - 1) * 100:.1f}% - the print will stretch slightly"
            )

        back_rgb = average_colour(back_pixels, back_mask)
        back_path = args.out_dir / f"{args.name}-back.webp"
        bake(back_pixels, back_bbox, back_rgb, args.tex_width).save(
            back_path, "WEBP", quality=92
        )
        print(f"  wrote {back_path}")
        back_ref = f'"{web_url(back_path)}"'

    rows = "\n".join(f"  [{x}, {y}]," for x, y in outline)

    args.module.parent.mkdir(parents=True, exist_ok=True)
    args.module.write_text(
        f"""// GENERATED by scripts/generate-shirt.py - do not edit by hand.
// Source image: {args.front}
//
// The outline is traced from the garment's alpha matte and the print is
// cropped to the same bounding box, which is why the planar UV projection
// lines up with the artwork without any manual alignment.

export const SHIRT_OUTLINE: ReadonlyArray<readonly [number, number]> = [
{rows}
];

export const SHIRT_ASSETS = {{
  front: "{web_url(front_path)}",
  back: {back_ref},
}} as const;

export const SHIRT_META = {{
  widthCm: {args.width_cm},
  heightCm: {round(height_cm, 1)},
  rimColor: "{rim_hex}",
  outlinePoints: {len(outline)},
}} as const;
"""
    )
    print(f"wrote {args.module}")

    print("\nNext: restart the dev server if HMR misses the new module, then check")
    print("the hero framing - a taller garment than the last one needs heroY and")
    print("CONFIG.camera.heroTarget nudging.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
