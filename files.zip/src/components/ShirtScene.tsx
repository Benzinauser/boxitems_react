import {
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type RefObject,
} from "react";

import * as THREE from "three";

import {
  Canvas,
  useFrame,
  useThree,
  type ThreeEvent,
} from "@react-three/fiber";

import {
  OrbitControls,
  ContactShadows,
  useTexture,
} from "@react-three/drei";

import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";

import {
  SHIRT_ASSETS,
  SHIRT_META,
  SHIRT_OUTLINE,
} from "./shirtAsset.generated";

/* ============================================================
   CONFIGURATION

   All visual and animation parameters live here.
============================================================ */

export const CONFIG = {
  colors: {
    cardboard: "#c8a06a",
    cardboardInside: "#a87d4c",
    cardboardEdges: "#9b7449",

    shirt: "#b61733",
    background: "#f1eee8",
  },

  box: {
    width: 2.5,
    depth: 2.0,
    height: 1.45,
    thickness: 0.055,
  },

  shirt: {
    // Outline, prints and rim colour come from shirtAsset.generated.ts,
    // which scripts/generate-shirt.py writes from flat-lay product photos.

    // The outline is authored in centimetre-like units and scaled once here,
    // so resizing the garment never means rewriting the shape.
    shapeScale: 0.022,

    // Bundled start height, low enough to stay inside the box.
    startY: 0.55,

    // Where the rise ends: just clear of the box rim. The remaining climb
    // happens during the unfold, so the bundle never hangs in mid-air.
    emergeY: 1.6,

    // Crumple amplitude of the bundled pose, in scene units.
    foldNoise: 0.07,

    // Garment depth and edge rounding, in shape units. A real shirt on a
    // torso is roughly 1/6 of its width, which is what makes the extrusion
    // read as volume rather than a card once it turns.
    extrusion: 20,
    bevelThickness: 2.5,
    bevelSize: 3,

    // How far the front and back caps bow outward, as a fraction of half
    // width. This is the "fake 3D": a body curve baked into the base mesh,
    // so the same flat print wraps like a worn garment from any angle.
    wrap: 0.34,

    sway: 0.035,
    swaySpeed: 1.5,

    // Slow yaw on the settled hero pose, in radians.
    yaw: 0.3,

    hoverLift: 0.16,

    heroY: 3.05,
  },

  timeline: {
    duration: 6,

    lidStart: 0,
    lidEnd: 0.8,

    riseStart: 0.6,
    riseEnd: 2,

    unfoldStart: 2,
    unfoldEnd: 4,

    settleStart: 4,
    settleEnd: 5.5,

    cameraStart: 5.5,
    cameraEnd: 6,
  },

  camera: {
    fov: 42,
    near: 0.1,
    far: 100,

    initialPosition: [5.2, 4.3, 7.5] as const,
    heroPosition: [0, 3.4, 9] as const,

    initialTarget: [0, 0.9, 0] as const,
    heroTarget: [0, 2.15, 0] as const,

    minDistance: 5,
    maxDistance: 12,

    minPolarAngle: Math.PI * 0.2,
    maxPolarAngle: Math.PI * 0.72,

    maxAzimuthAngle: Math.PI * 0.38,
  },

  lighting: {
    // Tuned for a printed albedo map, which reflects far less than the flat
    // off-white shirt this scene started with.
    ambient: 0.22,
    sky: 0.5,
    key: 38,
    fill: 18,
    rim: 26,
  },
} as const;

/* ============================================================
   MATH HELPERS
============================================================ */

function clamp01(value: number) {
  return THREE.MathUtils.clamp(value, 0, 1);
}

function progress(time: number, start: number, end: number) {
  // A zero-length phase would otherwise divide by zero and turn the whole
  // timeline into NaN the moment someone retunes CONFIG.
  if (end <= start) return time >= end ? 1 : 0;
  return clamp01((time - start) / (end - start));
}

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

function easeInOutCubic(t: number) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function smoothstep(t: number) {
  return t * t * (3 - 2 * t);
}

function vector3(values: readonly [number, number, number]) {
  return new THREE.Vector3(...values);
}

/* ============================================================
   TIMELINE

   A single mutable object shared by every animated part.

   One driver advances it and every other component reads from
   it inside the same frame, so the reveal is deterministic and
   directly scrubbable: seek(3.25) evaluates that instant.

   No React state is touched per frame.
============================================================ */

type Timeline = {
  time: number;
  playing: boolean;
  // Accumulated animation phase. Grows only while frames render,
  // so idle cloth motion never jumps after a demand-render gap.
  phase: number;
  notified: boolean;
};

function createTimeline(): Timeline {
  return { time: 0, playing: false, phase: 0, notified: false };
}

/* ============================================================
   PROCEDURAL BOX

   Five surfaces plus a hinged lid; no top face.
   Inner wall planes use a darker material.
============================================================ */

function CardboardBox({ timeline }: { timeline: Timeline }) {
  const lidPivot = useRef<THREE.Group>(null);

  const { width, depth, height, thickness } = CONFIG.box;

  const materials = useMemo(() => {
    const cardboard = new THREE.MeshStandardMaterial({
      color: CONFIG.colors.cardboard,
      roughness: 0.95,
      metalness: 0,
      side: THREE.DoubleSide,
    });

    const inside = new THREE.MeshStandardMaterial({
      color: CONFIG.colors.cardboardInside,
      roughness: 1,
      metalness: 0,
      side: THREE.DoubleSide,
    });

    const edges = new THREE.MeshStandardMaterial({
      color: CONFIG.colors.cardboardEdges,
      roughness: 1,
    });

    return { cardboard, inside, edges };
  }, []);

  useEffect(
    () => () => {
      materials.cardboard.dispose();
      materials.inside.dispose();
      materials.edges.dispose();
    },
    [materials]
  );

  // Phase 1: 0.0-0.8s, lid swings to roughly 115 degrees.
  useFrame(() => {
    if (!lidPivot.current) return;

    const p = easeOutCubic(
      progress(timeline.time, CONFIG.timeline.lidStart, CONFIG.timeline.lidEnd)
    );

    lidPivot.current.rotation.x = -p * Math.PI * 0.64;
  });

  const wallY = height / 2;
  const inner = thickness / 2 + 0.002;

  return (
    <group>
      <mesh position={[0, thickness / 2, 0]} material={materials.cardboard} receiveShadow>
        <boxGeometry args={[width, thickness, depth]} />
      </mesh>

      {/* Front wall */}
      <mesh position={[0, wallY, depth / 2]} material={materials.cardboard} castShadow receiveShadow>
        <boxGeometry args={[width, height, thickness]} />
      </mesh>
      <mesh
        position={[0, wallY, depth / 2 - inner]}
        rotation={[0, Math.PI, 0]}
        material={materials.inside}
      >
        <planeGeometry args={[width, height]} />
      </mesh>

      {/* Back wall */}
      <mesh position={[0, wallY, -depth / 2]} material={materials.cardboard} castShadow>
        <boxGeometry args={[width, height, thickness]} />
      </mesh>
      <mesh position={[0, wallY, -depth / 2 + inner]} material={materials.inside}>
        <planeGeometry args={[width, height]} />
      </mesh>

      {/* Left wall */}
      <mesh position={[-width / 2, wallY, 0]} material={materials.cardboard} castShadow>
        <boxGeometry args={[thickness, height, depth]} />
      </mesh>
      <mesh
        position={[-width / 2 + inner, wallY, 0]}
        rotation={[0, Math.PI / 2, 0]}
        material={materials.inside}
      >
        <planeGeometry args={[depth, height]} />
      </mesh>

      {/* Right wall */}
      <mesh position={[width / 2, wallY, 0]} material={materials.cardboard} castShadow>
        <boxGeometry args={[thickness, height, depth]} />
      </mesh>
      <mesh
        position={[width / 2 - inner, wallY, 0]}
        rotation={[0, -Math.PI / 2, 0]}
        material={materials.inside}
      >
        <planeGeometry args={[depth, height]} />
      </mesh>

      {/* Hinged lid */}
      <group ref={lidPivot} position={[0, height, -depth / 2]}>
        <mesh position={[0, 0, depth / 2]} material={materials.cardboard} castShadow>
          <boxGeometry args={[width + thickness, thickness, depth]} />
        </mesh>

        <mesh
          position={[0, -thickness / 2 - 0.002, depth / 2]}
          material={materials.edges}
        >
          <boxGeometry args={[width, 0.008, depth * 0.96]} />
        </mesh>
      </group>
    </group>
  );
}

/* ============================================================
   T-SHIRT SHAPE

   The outline, the print paths and the rim colour all come from
   shirtAsset.generated.ts, which scripts/generate-shirt.py writes from
   flat-lay product photos. Nothing here is hand-authored, so swapping
   garments means re-running the script, not editing this file.
============================================================ */

const HAS_BACK_PRINT = SHIRT_ASSETS.back !== null;

function createShirtGeometry() {
  const shape = new THREE.Shape();

  shape.moveTo(SHIRT_OUTLINE[0][0], SHIRT_OUTLINE[0][1]);
  for (let i = 1; i < SHIRT_OUTLINE.length; i++) {
    shape.lineTo(SHIRT_OUTLINE[i][0], SHIRT_OUTLINE[i][1]);
  }

  shape.closePath();

  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: CONFIG.shirt.extrusion,
    bevelEnabled: true,
    bevelThickness: CONFIG.shirt.bevelThickness,
    bevelSize: CONFIG.shirt.bevelSize,
    bevelSegments: 2,
    // The contour is all straight segments; nothing to tessellate.
    curveSegments: 1,
    steps: 1,
  });

  geometry.center();

  const s = CONFIG.shirt.shapeScale;
  geometry.scale(s, s, s);

  const nonIndexed = geometry.index ? geometry.toNonIndexed() : geometry;

  if (nonIndexed !== geometry) geometry.dispose();

  const mapped = mapShirtFaces(nonIndexed, HAS_BACK_PRINT);

  applyBodyWrap(mapped);

  const restNormals = computeWeldedNormals(mapped);
  mapped.setAttribute("normal", new THREE.BufferAttribute(restNormals, 3));

  /*
     Set the sphere explicitly. Three otherwise computes it lazily on the
     first pointer hit, which can land while the shirt is still bundled and
     small - after that every raycast against the full-size garment is
     rejected early and hover looks permanently dead.
  */
  mapped.computeBoundingSphere();

  if (mapped.boundingSphere) {
    mapped.boundingSphere.radius +=
      CONFIG.shirt.wrap + CONFIG.shirt.sway * 2 + CONFIG.shirt.foldNoise;
  }

  return { geometry: mapped, restNormals };
}

/*
   Bow the caps outward around the vertical axis, with a shallower curve
   around the horizontal one.

   This is the "fake 3D": a body shape baked into the base mesh, so the same
   flat print wraps like worn fabric instead of sliding past you like a card
   as the view turns. Front and back get the same offset, keeping the two
   surfaces parallel the way a garment over a torso is.
*/
function applyBodyWrap(geometry: THREE.BufferGeometry) {
  const position = geometry.getAttribute("position") as THREE.BufferAttribute;

  geometry.computeBoundingBox();
  const box = geometry.boundingBox ?? new THREE.Box3();

  const halfWidth = (box.max.x - box.min.x) / 2 || 1;
  const halfHeight = (box.max.y - box.min.y) / 2 || 1;
  const centreX = (box.max.x + box.min.x) / 2;
  const centreY = (box.max.y + box.min.y) / 2;

  const amount = CONFIG.shirt.wrap * halfWidth;

  for (let i = 0; i < position.count; i++) {
    const u = (position.getX(i) - centreX) / halfWidth;
    const v = (position.getY(i) - centreY) / halfHeight;

    position.setZ(i, position.getZ(i) - amount * (u * u + 0.3 * v * v));
  }

  position.needsUpdate = true;
}

/*
   Normals averaged over coincident vertices.

   The mesh is non-indexed, so computeVertexNormals() would give each triangle
   its own flat normal and the body wrap would shade like faceted sheet metal.
   Welding by position first lets the curve read as smooth cloth, and caching
   the result is what makes it possible to stop recomputing normals every
   frame once the shirt settles.
*/
function computeWeldedNormals(geometry: THREE.BufferGeometry) {
  const position = geometry.getAttribute("position") as THREE.BufferAttribute;
  const count = position.count;

  const accumulated = new Float32Array(count * 3);
  const representative = new Int32Array(count);
  const byKey = new Map<string, number>();

  const a = new THREE.Vector3();
  const b = new THREE.Vector3();
  const c = new THREE.Vector3();
  const ab = new THREE.Vector3();
  const ac = new THREE.Vector3();
  const face = new THREE.Vector3();

  for (let t = 0; t < count; t += 3) {
    a.fromBufferAttribute(position, t);
    b.fromBufferAttribute(position, t + 1);
    c.fromBufferAttribute(position, t + 2);

    ab.subVectors(b, a);
    ac.subVectors(c, a);
    face.crossVectors(ab, ac).normalize();

    for (let j = 0; j < 3; j++) {
      const i = t + j;
      const key = `${position.getX(i).toFixed(4)} ${position
        .getY(i)
        .toFixed(4)} ${position.getZ(i).toFixed(4)}`;

      let anchor = byKey.get(key);

      if (anchor === undefined) {
        anchor = i;
        byKey.set(key, i);
      }

      representative[i] = anchor;

      accumulated[anchor * 3] += face.x;
      accumulated[anchor * 3 + 1] += face.y;
      accumulated[anchor * 3 + 2] += face.z;
    }
  }

  const normals = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    const anchor = representative[i] * 3;
    const length =
      Math.hypot(accumulated[anchor], accumulated[anchor + 1], accumulated[anchor + 2]) ||
      1;

    normals[i * 3] = accumulated[anchor] / length;
    normals[i * 3 + 1] = accumulated[anchor + 1] / length;
    normals[i * 3 + 2] = accumulated[anchor + 2] / length;
  }

  return normals;
}

/*
   Split the mesh into up to three draw groups.

     front cap -> group 0, front print
     back cap  -> group 1, back print, mirrored horizontally
     rim       -> group 2, flat colour

   The rim needs its own group because the extrusion is ~9cm thick: sampling a
   print across it smears the badge and sleeve graphics into a streak running
   the whole length of the silhouette edge.

   With no back photo, back-facing triangles fall into the rim group and the
   mesh draws twice instead of three times.

   Triangles are physically reordered so each group stays contiguous, since
   three issues one draw call per group.
*/
function mapShirtFaces(geometry: THREE.BufferGeometry, hasBack: boolean) {
  const position = geometry.getAttribute("position") as THREE.BufferAttribute;
  const source = position.array as Float32Array;
  const vertexCount = position.count;

  geometry.computeBoundingBox();
  const box = geometry.boundingBox ?? new THREE.Box3();
  const extent = new THREE.Vector3();
  box.getSize(extent);

  // Pull the UV rect inward so no triangle samples the image border.
  const inset = 0.006;
  const span = 1 - 2 * inset;

  const a = new THREE.Vector3();
  const b = new THREE.Vector3();
  const c = new THREE.Vector3();
  const ab = new THREE.Vector3();
  const ac = new THREE.Vector3();
  const normal = new THREE.Vector3();

  const front: number[] = [];
  const back: number[] = [];
  const rim: number[] = [];

  for (let t = 0; t < vertexCount; t += 3) {
    a.fromBufferAttribute(position, t);
    b.fromBufferAttribute(position, t + 1);
    c.fromBufferAttribute(position, t + 2);

    ab.subVectors(b, a);
    ac.subVectors(c, a);
    normal.crossVectors(ab, ac).normalize();

    // Wall triangles have a near-zero z normal; caps sit close to +/-1.
    if (normal.z > 0.7) front.push(t);
    else if (hasBack && normal.z < -0.7) back.push(t);
    else rim.push(t);
  }

  const positions = new Float32Array(source.length);
  const uvs = new Float32Array(vertexCount * 2);

  let written = 0;

  const copy = (from: number, face: "front" | "back" | null) => {
    const s3 = from * 3;
    const d3 = written * 3;
    const d2 = written * 2;

    positions[d3] = source[s3];
    positions[d3 + 1] = source[s3 + 1];
    positions[d3 + 2] = source[s3 + 2];

    if (face) {
      const u = inset + ((source[s3] - box.min.x) / extent.x) * span;
      const v = inset + ((source[s3 + 1] - box.min.y) / extent.y) * span;

      // Seen from behind, +x falls on the viewer's left, so the back print is
      // flipped horizontally or its artwork reads reversed.
      uvs[d2] = face === "back" ? 1 - u : u;
      uvs[d2 + 1] = v;
    } else {
      uvs[d2] = 0;
      uvs[d2 + 1] = 0;
    }

    written++;
  };

  for (const start of front) {
    copy(start, "front");
    copy(start + 1, "front");
    copy(start + 2, "front");
  }

  for (const start of back) {
    copy(start, "back");
    copy(start + 1, "back");
    copy(start + 2, "back");
  }

  for (const start of rim) {
    copy(start, null);
    copy(start + 1, null);
    copy(start + 2, null);
  }

  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geometry.deleteAttribute("normal");
  geometry.computeVertexNormals();

  const frontCount = front.length * 3;
  const backCount = back.length * 3;

  geometry.clearGroups();
  geometry.addGroup(0, frontCount, 0);
  if (backCount) geometry.addGroup(frontCount, backCount, 1);
  geometry.addGroup(frontCount + backCount, rim.length * 3, 2);

  return geometry;
}

/*
   Deterministic hash of a base position. Vertices that share a location
   (cap meeting wall) therefore fold to the same point, so the surface
   cannot tear mid-unfold. A per-iteration RNG would not have that
   property, because duplicated vertices draw different numbers.
*/
function hash3(x: number, y: number, z: number) {
  const n = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453;
  return n - Math.floor(n);
}

/*
   The bundled pose, precomputed once. Width and height squash hard while
   depth puffs outward, which reads as a stacked bundle rather than a
   shrink-wrapped miniature shirt.
*/
function buildFoldedPositions(base: Float32Array, amount: number) {
  const folded = new Float32Array(base.length);
  const count = base.length / 3;

  let cx = 0,
    cy = 0,
    cz = 0;

  for (let i = 0; i < base.length; i += 3) {
    cx += base[i];
    cy += base[i + 1];
    cz += base[i + 2];
  }

  cx /= count;
  cy /= count;
  cz /= count;

  for (let i = 0; i < base.length; i += 3) {
    const x = base[i];
    const y = base[i + 1];
    const z = base[i + 2];

    const n = hash3(x, y, z);
    const wrinkle = Math.sin(n * 6.283 + y * 7.3) * Math.cos(x * 5.1 - n * 3.7);

    folded[i] = cx + (x - cx) * 0.3 + wrinkle * amount;
    folded[i + 1] = cy + (y - cy) * 0.16 + wrinkle * amount * 0.5;
    folded[i + 2] =
      cz +
      (z - cz) * 1.6 +
      Math.sin(n * 12.566 + x * 6.2) * amount * 1.8;
  }

  return folded;
}

/* ============================================================
   PROCEDURAL SHIRT

   Deformed from immutable base positions every frame, so no
   distortion accumulates. Three layers:

     1. folded bundle   2. unfold interpolation   3. cloth sway
============================================================ */

function ProceduralShirt({
  timeline,
  hovered,
  setHovered,
  reducedMotion,
}: {
  timeline: Timeline;
  hovered: boolean;
  setHovered: (value: boolean) => void;
  reducedMotion: boolean;
}) {
  const gl = useThree((state) => state.gl);
  const { invalidate } = useThree();

  const group = useRef<THREE.Group>(null);

  const { geometry, restNormals } = useMemo(() => createShirtGeometry(), []);

  /*
     Two textures are always requested so hook order stays fixed whether or not
     a back photo exists; the second slot reuses the front when there is none.
  */
  const [frontMap, backMap] = useTexture([
    SHIRT_ASSETS.front,
    SHIRT_ASSETS.back ?? SHIRT_ASSETS.front,
  ]);

  useEffect(() => {
    for (const texture of [frontMap, backMap]) {
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.wrapS = THREE.ClampToEdgeWrapping;
      texture.wrapT = THREE.ClampToEdgeWrapping;
      texture.anisotropy = gl.capabilities.getMaxAnisotropy();
      texture.needsUpdate = true;
    }
  }, [frontMap, backMap, gl]);

  /*
     Index matches the draw groups built in mapShirtFaces: printed front cap,
     printed back cap when one exists, flat colour for the rim.
  */
  const materials = useMemo(() => {
    const printed = (map: THREE.Texture) =>
      new THREE.MeshStandardMaterial({
        map,
        // A football shirt is woven synthetic with a slight sheen, not cotton.
        roughness: 0.58,
        metalness: 0.05,
        side: THREE.DoubleSide,
      });

    const flat = () =>
      new THREE.MeshStandardMaterial({
        color: SHIRT_META.rimColor,
        roughness: 0.62,
        metalness: 0.05,
        side: THREE.DoubleSide,
      });

    return [
      printed(frontMap),
      SHIRT_ASSETS.back ? printed(backMap) : flat(),
      flat(),
    ];
  }, [frontMap, backMap]);

  const { basePositions, foldedPositions } = useMemo(() => {
    const base = Float32Array.from(
      geometry.getAttribute("position").array as Float32Array
    );

    return {
      basePositions: base,
      foldedPositions: buildFoldedPositions(base, CONFIG.shirt.foldNoise),
    };
  }, [geometry]);

  const hoverAmount = useRef(0);
  const atRest = useRef(false);

  /*
     The texture itself is left alone: drei caches it, and disposing a cached
     asset from one instance would break the next.
  */
  useEffect(
    () => () => {
      geometry.dispose();
      materials.forEach((material) => material.dispose());
    },
    [geometry, materials]
  );

  useFrame((_, delta) => {
    if (!group.current) return;

    const t = timeline.time;

    // Phase 2: 0.6-2.0s, the bundle rises out of the box.
    const rise = easeInOutCubic(
      progress(t, CONFIG.timeline.riseStart, CONFIG.timeline.riseEnd)
    );

    // Phase 3: 2.0-4.0s, vertices interpolate folded -> silhouette.
    const unfold = smoothstep(
      progress(t, CONFIG.timeline.unfoldStart, CONFIG.timeline.unfoldEnd)
    );

    // Phase 4: 4.0-5.5s, orientation eases front-facing.
    const settle = easeInOutCubic(
      progress(t, CONFIG.timeline.settleStart, CONFIG.timeline.settleEnd)
    );

    hoverAmount.current = THREE.MathUtils.damp(
      hoverAmount.current,
      hovered ? 1 : 0,
      5,
      Math.min(delta, 0.05)
    );

    const hover = hoverAmount.current;
    const motion = reducedMotion ? 0 : 1;

    const idleTime = timeline.phase * CONFIG.shirt.swaySpeed * (1 + hover * 1.4);

    const floatAmount = Math.sin(idleTime * 0.9) * 0.045 * settle * motion;

    // Two legs: bundled out of the box, then climbing into hero position
    // while it opens up.
    const climbY = THREE.MathUtils.lerp(
      CONFIG.shirt.startY,
      CONFIG.shirt.emergeY,
      rise
    );

    group.current.position.set(
      0,
      climbY +
        THREE.MathUtils.lerp(
          0,
          CONFIG.shirt.heroY - CONFIG.shirt.emergeY,
          unfold
        ) +
        floatAmount +
        hover * CONFIG.shirt.hoverLift,
      0
    );

    group.current.rotation.set(
      THREE.MathUtils.lerp(-0.9, 0, unfold),
      THREE.MathUtils.lerp(-0.55, 0, settle) +
        Math.sin(idleTime * 0.3) * CONFIG.shirt.yaw * settle * motion,
      THREE.MathUtils.lerp(0.38, 0, settle)
    );

    /*
       Once the garment is fully unfolded, the vertex loop and the normal
       rebuild are pure cost - the shape is static, and the float, yaw and
       hover lift above all live on the group. Snap to the cached rest state
       once, then skip the per-vertex work entirely. This is what keeps
       orbiting smooth; the cloth sway is only live during the reveal.
    */
    if (unfold >= 1) {
      if (!atRest.current) {
        const attribute = geometry.getAttribute("position") as THREE.BufferAttribute;
        attribute.array.set(basePositions);
        attribute.needsUpdate = true;

        const normal = geometry.getAttribute("normal") as THREE.BufferAttribute;
        normal.array.set(restNormals);
        normal.needsUpdate = true;

        atRest.current = true;
      }

      return;
    }

    atRest.current = false;

    const position = geometry.getAttribute("position") as THREE.BufferAttribute;

    const swayStrength = CONFIG.shirt.sway * (0.3 + unfold * 0.7) * motion;

    for (let i = 0; i < position.count; i++) {
      const index = i * 3;

      const x = basePositions[index];
      const y = basePositions[index + 1];
      const z = basePositions[index + 2];

      let px = THREE.MathUtils.lerp(foldedPositions[index], x, unfold);
      let py = THREE.MathUtils.lerp(foldedPositions[index + 1], y, unfold);
      let pz = THREE.MathUtils.lerp(foldedPositions[index + 2], z, unfold);

      // Sway is strongest at the sleeves and hem.
      const edgeWeight = Math.min(
        1,
        Math.abs(x) * 0.5 + Math.max(0, -y) * 0.3
      );

      pz +=
        Math.sin(idleTime * 1.7 + x * 2.6 + y * 1.8) *
        swayStrength *
        edgeWeight *
        (1 + hover * 0.7);

      px +=
        Math.sin(idleTime * 1.1 + y * 2) *
        swayStrength *
        0.15 *
        unfold;

      position.setXYZ(i, px, py, pz);
    }

    position.needsUpdate = true;
    geometry.computeVertexNormals();
  });

  return (
    <group ref={group}>
      {/*
        Hover is scoped to the garment rather than the whole assembly, so
        pointing at the box does not trigger the lift.
      */}
      <mesh
        geometry={geometry}
        material={materials}
        castShadow
        receiveShadow
        onPointerOver={(event: ThreeEvent<PointerEvent>) => {
          event.stopPropagation();
          setHovered(true);
          invalidate();
        }}
        onPointerOut={() => {
          setHovered(false);
          invalidate();
        }}
      />
    </group>
  );
}

/* ============================================================
   CAMERA

   Phase 5: 5.5-6.0s eases into hero framing. OrbitControls stay
   disabled until the reveal ends, so nothing fights this lerp.
============================================================ */

function AnimatedCamera({
  timeline,
  controls,
}: {
  timeline: Timeline;
  controls: RefObject<OrbitControlsImpl | null>;
}) {
  const camera = useThree((state) => state.camera);

  const initialPosition = useMemo(
    () => vector3(CONFIG.camera.initialPosition),
    []
  );
  const heroPosition = useMemo(() => vector3(CONFIG.camera.heroPosition), []);
  const initialTarget = useMemo(() => vector3(CONFIG.camera.initialTarget), []);
  const heroTarget = useMemo(() => vector3(CONFIG.camera.heroTarget), []);

  const target = useMemo(() => new THREE.Vector3(), []);

  const handedOff = useRef(false);

  useFrame(() => {
    const instance = controls.current;

    const done = timeline.time >= CONFIG.timeline.duration;

    // After the final frame is applied, OrbitControls owns the camera.
    if (done && handedOff.current) return;

    const p = easeInOutCubic(
      progress(
        timeline.time,
        CONFIG.timeline.cameraStart,
        CONFIG.timeline.cameraEnd
      )
    );

    camera.position.lerpVectors(initialPosition, heroPosition, p);
    target.lerpVectors(initialTarget, heroTarget, p);

    if (instance) {
      instance.target.copy(target);
      instance.update();
    } else {
      camera.lookAt(target);
    }

    if (done) handedOff.current = true;
  });

  return null;
}

/* ============================================================
   STUDIO LIGHTING

   Warm key, soft cool fill, white rim. No HDRI.
============================================================ */

function StudioLighting() {
  return (
    <>
      <ambientLight intensity={CONFIG.lighting.ambient} />

      {/* A sky/ground split tints the underside warm and reads as a room. */}
      <hemisphereLight
        args={["#ffffff", "#777766", CONFIG.lighting.sky]}
      />

      <directionalLight
        position={[4, 7, 5]}
        intensity={CONFIG.lighting.key / 10}
        color="#fff3df"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-4}
        shadow-camera-right={4}
        shadow-camera-top={6}
        shadow-camera-bottom={-4}
        shadow-bias={-0.0002}
      />

      <directionalLight
        position={[-5, 3, 4]}
        intensity={CONFIG.lighting.fill / 10}
        color="#dce8ff"
      />

      <directionalLight
        position={[1, 5, -5]}
        intensity={CONFIG.lighting.rim / 10}
        color="#ffffff"
      />
    </>
  );
}

/* ============================================================
   SCENE
============================================================ */

function SceneContent({
  timeline,
  hovered,
  setHovered,
  awake,
  reducedMotion,
  onRevealComplete,
}: {
  timeline: Timeline;
  hovered: boolean;
  setHovered: (value: boolean) => void;
  awake: boolean;
  reducedMotion: boolean;
  onRevealComplete: () => void;
}) {
  const controls = useRef<OrbitControlsImpl>(null);

  /*
   Priority -2 keeps this subscriber ahead of drei's OrbitControls
   (-1) and every part (0), so the whole scene reads one coherent
   time value per frame. Only priority > 0 opts out of automatic
   rendering, so a negative value is safe here.
  */
  useFrame((state, delta) => {
    /*
       Only guard against a huge jump (backgrounded tab, long GC pause). A
       tight clamp here makes the reveal run in slow motion on a weak GPU,
       because the timeline then advances per *frame* rather than per second.
    */
    const step = Math.min(delta, 0.25);

    timeline.phase += step;

    if (timeline.playing) {
      timeline.time = Math.min(timeline.time + step, CONFIG.timeline.duration);

      if (timeline.time >= CONFIG.timeline.duration) {
        timeline.playing = false;

        if (!timeline.notified) {
          timeline.notified = true;
          onRevealComplete();
        }
      }
    }

    const interactive =
      !timeline.playing && timeline.time >= CONFIG.timeline.duration;

    if (controls.current && controls.current.enabled !== interactive) {
      controls.current.enabled = interactive;
    }

    if (awake) state.invalidate();
  }, -2);

  return (
    <>
      <StudioLighting />

      <CardboardBox timeline={timeline} />

      <ProceduralShirt
        timeline={timeline}
        hovered={hovered}
        setHovered={setHovered}
        reducedMotion={reducedMotion}
      />

      {/* Invisible floor catches the directional shadow. */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.035, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <shadowMaterial transparent opacity={0.14} />
      </mesh>

      <ContactShadows
        position={[0, -0.025, 0]}
        opacity={0.28}
        scale={6}
        blur={2.6}
        far={4}
        resolution={256}
        color="#655848"
        frames={1}
      />

      <OrbitControls
        ref={controls}
        enabled={false}
        enablePan={false}
        enableZoom
        enableRotate
        minDistance={CONFIG.camera.minDistance}
        maxDistance={CONFIG.camera.maxDistance}
        minPolarAngle={CONFIG.camera.minPolarAngle}
        maxPolarAngle={CONFIG.camera.maxPolarAngle}
        minAzimuthAngle={-CONFIG.camera.maxAzimuthAngle}
        maxAzimuthAngle={CONFIG.camera.maxAzimuthAngle}
        enableDamping
        dampingFactor={0.07}
      />

      <AnimatedCamera timeline={timeline} controls={controls} />
    </>
  );
}

/* ============================================================
   MAIN COMPONENT
============================================================ */

export default function ShirtScene() {
  const containerRef = useRef<HTMLDivElement>(null);

  const timeline = useRef(createTimeline()).current;

  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [started, setStarted] = useState(false);
  const [interactive, setInteractive] = useState(false);

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");

    const update = () => setReducedMotion(query.matches);

    update();

    query.addEventListener("change", update);

    return () => query.removeEventListener("change", update);
  }, []);

  /*
   The reveal begins when the section actually enters the
   viewport, and rendering pauses once it scrolls away.
  */
  useEffect(() => {
    const element = containerRef.current;

    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { threshold: 0.25 }
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible || started) return;

    setStarted(true);

    if (reducedMotion) {
      timeline.time = CONFIG.timeline.duration;
      timeline.playing = false;
      setInteractive(true);
    } else {
      timeline.time = 0;
      timeline.notified = false;
      timeline.playing = true;
    }
  }, [visible, started, reducedMotion, timeline]);

  const handleReplay = useCallback(() => {
    setHovered(false);

    timeline.time = 0;
    timeline.notified = false;
    timeline.playing = true;
    setInteractive(false);
  }, [timeline]);

  return (
    <div ref={containerRef} className="shirt-scene">
      <Canvas
        frameloop="demand"
        dpr={[1, 2]}
        shadows="percentage"
        gl={{
          alpha: true,
          antialias: true,
          powerPreference: "high-performance",
        }}
        camera={{
          fov: CONFIG.camera.fov,
          near: CONFIG.camera.near,
          far: CONFIG.camera.far,
          position: [...CONFIG.camera.initialPosition],
        }}
        style={{ width: "100%", height: "100%", background: "transparent" }}
      >
        <Suspense fallback={null}>
          <SceneContent
            timeline={timeline}
            hovered={hovered}
            setHovered={setHovered}
            awake={visible && (!reducedMotion || hovered)}
            reducedMotion={reducedMotion}
            onRevealComplete={() => setInteractive(true)}
          />
        </Suspense>
      </Canvas>

      <div className="scene-ui">
        <div className="scene-label">
          <span className="eyebrow">THE REVEAL</span>
          <h2>Made to move.</h2>
          <p>A little something worth unboxing.</p>
        </div>

        <div className="scene-actions">
          <span className="interaction-hint">
            {interactive ? "Drag to explore" : ""}
          </span>

          {/*
            Hidden rather than inert: replaying would reintroduce the motion
            the visitor opted out of, so the control would only ever lie.
          */}
          {!reducedMotion && (
            <button
              type="button"
              onClick={handleReplay}
              className="replay-button"
              aria-label="Replay t-shirt reveal animation"
            >
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M3 11a9 9 0 1 1 2.5 6.2" />
                <path d="M3 4v7h7" />
              </svg>

              Replay
            </button>
          )}
        </div>
      </div>

      <style>{`
        .shirt-scene {
          width: 100%;
          height: 100%;
          position: relative;
          overflow: hidden;
          isolation: isolate;
        }

        .scene-ui {
          position: absolute;
          inset: 0;

          display: flex;
          flex-direction: column;
          justify-content: space-between;

          padding: clamp(24px, 5vw, 72px);

          pointer-events: none;
          z-index: 2;
        }

        .scene-label { max-width: 420px; }

        .eyebrow {
          font-family: system-ui, sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.22em;
          color: #9c7956;
        }

        .scene-label h2 {
          font-family: Georgia, "Times New Roman", serif;
          font-size: clamp(38px, 5vw, 76px);
          line-height: 0.98;
          letter-spacing: -0.05em;
          font-weight: 400;
          color: #302a25;
          margin: 18px 0;
        }

        .scene-label p {
          font-family: system-ui, sans-serif;
          font-size: 14px;
          line-height: 1.7;
          color: #81776b;
        }

        .scene-actions {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
        }

        .interaction-hint {
          font-family: system-ui, sans-serif;
          font-size: 11px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #8c8277;
        }

        .replay-button {
          pointer-events: auto;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 12px;

          padding: 14px 22px;

          border-radius: 999px;
          border: 1px solid rgba(70, 55, 40, 0.16);
          background: rgba(255, 255, 255, 0.65);
          backdrop-filter: blur(12px);

          color: #40362e;
          font-family: system-ui, sans-serif;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;

          transition: background 200ms ease, transform 200ms ease, box-shadow 200ms ease;
        }

        .replay-button:hover {
          background: white;
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(40, 30, 20, 0.08);
        }

        .replay-button:focus-visible {
          outline: 2px solid #9c7956;
          outline-offset: 4px;
        }

        @media (max-width: 640px) {
          .scene-ui { padding: 26px; }
          .scene-label h2 { font-size: 42px; }
          .scene-label p { font-size: 12px; }
          .interaction-hint { font-size: 9px; }
          .replay-button { padding: 12px 16px; }
        }
      `}</style>
    </div>
  );
}
